DROP SCHEMA project;
CREATE SCHEMA project;
USE project;

CREATE TABLE operator 
(ID INTEGER NOT NULL AUTO_INCREMENT,
FirstName VARCHAR(50),
LastName VARCHAR(50),
StreetNumber INTEGER,
HouseNumber  INTEGER,
City VARCHAR(50),
Mail VARCHAR(50),
ManagerID INTEGER,
PRIMARY KEY(ID),
FOREIGN KEY (ManagerID) REFERENCES operator(ID) on delete cascade)
ENGINE=INNODB;

CREATE TABLE phoneNumbers
(PhoneNumber VARCHAR(50) NOT NULL,
OperatorID INTEGER NOT NULL,
PRIMARY KEY (PhoneNumber,OperatorID),
FOREIGN KEY (OperatorID) REFERENCES operator(ID) on delete cascade)
ENGINE=INNODB;


CREATE TABLE applications
(ID INTEGER NOT NULL AUTO_INCREMENT,
ApplicationDate DATE,
ApplicationDescription VARCHAR(100),
ContactName VARCHAR(50),
ContactPhoneN VARCHAR(50),
OperatorID INTEGER NOT NULL,
PRIMARY KEY (ID),
FOREIGN KEY (OperatorID) REFERENCES operator(ID) ON UPDATE CASCADE)
ENGINE=INNODB;
ALTER TABLE applications AUTO_INCREMENT=111;


CREATE TABLE road
(ID INTEGER NOT NULL,
RoadName VARCHAR(50),
RoadLength INTEGER,
RoadType VARCHAR(50),
PRIMARY KEY (ID))
ENGINE=INNODB;

CREATE TABLE roadSection
(ID INTEGER NOT NULL,
SideLighting ENUM('NONE','LEFT','RIGHT','BOTH'),
Marings ENUM('NONE','LEFT','RIGHT','BOTH'),
RoadID INTEGER NOT NULL,
PRIMARY KEY  (ID,RoadID),
FOREIGN KEY (RoadID) REFERENCES road(ID) on delete cascade)
ENGINE=INNODB;


CREATE TABLE treatmentFactor
(ID INTEGER NOT NULL,
FactorName VARCHAR(50),
PhoneNumber VARCHAR(50),
Mail VARCHAR(50),
PRIMARY KEY (ID))
ENGINE=INNODB; 



CREATE TABLE hazardType
(TypeName VARCHAR(50) NOT NULL,
Cost INTEGER,
TreatmentFactorID INTEGER,
PRIMARY KEY (TypeName),
FOREIGN KEY (TreatmentFactorID) REFERENCES treatmentFactor(ID) on delete cascade)
ENGINE=INNODB;


CREATE TABLE hazard
(ID INTEGER NOT NULL,
EvacuationDate DATE,
Location VARCHAR(50),
HazardTypeName VARCHAR(50),
RoadId INTEGER,
RoadSectionID INTEGER,
PRIMARY KEY (ID),
FOREIGN KEY (HazardTypeName) REFERENCES hazardType(TypeName) on delete cascade,
FOREIGN KEY (RoadId) REFERENCES road(ID) on delete cascade,
FOREIGN KEY (RoadSectionID) REFERENCES roadSection(ID) on delete cascade)
ENGINE=INNODB;

 
CREATE TABLE treatment
(ApplicationID INTEGER NOT NULL,
HazardID INTEGER NOT NULL,
PRIMARY KEY (ApplicationID,HazardID),
FOREIGN KEY (ApplicationID) REFERENCES applications(ID) on delete cascade,
FOREIGN KEY (HazardID) REFERENCES hazard(ID) on delete cascade)
ENGINE=INNODB;



INSERT INTO `project`.`operator` (`FirstName`,`LastName`,`StreetNumber`,`HouseNumber`,`City`,`Mail`,`ManagerID`) VALUES ('Ron','Levi',1,2,'Tel Aviv','ron@gmail.com',1);
INSERT INTO `project`.`operator` (`FirstName`,`LastName`,`StreetNumber`,`HouseNumber`,`City`,`Mail`,`ManagerID`) VALUES ('Ariel','Ella',23,45,'Hadera','ariel@gmail.com',1);
INSERT INTO `project`.`operator` (`FirstName`,`LastName`,`StreetNumber`,`HouseNumber`,`City`,`Mail`,`ManagerID`) VALUES ('Inbal','Barzel',44,77,'Tel Aviv','inbal@gmail.com',1);
INSERT INTO `project`.`operator` (`FirstName`,`LastName`,`StreetNumber`,`HouseNumber`,`City`,`Mail`,`ManagerID`) VALUES ('Shir','Choen',24,89,'Yavne','shiroshl@gmail.com',2);
INSERT INTO `project`.`operator` (`FirstName`,`LastName`,`StreetNumber`,`HouseNumber`,`City`,`Mail`,`ManagerID`) VALUES ('Yarin','Chen',13,56,'Yahood','yarini@gmail.com',2);
INSERT INTO `project`.`operator` (`FirstName`,`LastName`,`StreetNumber`,`HouseNumber`,`City`,`Mail`,`ManagerID`) VALUES ('Rotem','Kaspin',22,45,'Binyamina','Rotem@gmail.com',2);



INSERT INTO `project`.`phonenumbers` (`PhoneNumber`,`OperatorID`) VALUES ('0504304933',1);
INSERT INTO `project`.`phonenumbers` (`PhoneNumber`,`OperatorID`) VALUES ('0509332188',1);
INSERT INTO `project`.`phonenumbers` (`PhoneNumber`,`OperatorID`) VALUES ('0508392332',2);
INSERT INTO `project`.`phonenumbers` (`PhoneNumber`,`OperatorID`) VALUES ('0523456783',2);
INSERT INTO `project`.`phonenumbers` (`PhoneNumber`,`OperatorID`) VALUES ('0507505163',3);
INSERT INTO `project`.`phonenumbers` (`PhoneNumber`,`OperatorID`) VALUES ('0523940329',3);
INSERT INTO `project`.`phonenumbers` (`PhoneNumber`,`OperatorID`) VALUES ('0533489302',4);
INSERT INTO `project`.`phonenumbers` (`PhoneNumber`,`OperatorID`) VALUES ('0503489382',5);
INSERT INTO `project`.`phonenumbers` (`PhoneNumber`,`OperatorID`) VALUES ('0538928292',6);
INSERT INTO `project`.`phonenumbers` (`PhoneNumber`,`OperatorID`) VALUES ('0572938372',6);



INSERT INTO `project`.`applications` (`ApplicationDate`,`ApplicationDescription`,`ContactName`,`ContactPhoneN`,`OperatorID`) VALUES ('2021-04-16','A lamp on the right side of the road doesnt light up','roi','0529443265',2);
INSERT INTO `project`.`applications` (`ApplicationDate`,`ApplicationDescription`,`ContactName`,`ContactPhoneN`,`OperatorID`) VALUES ('2020-07-13','A lamp on the left  side of the road doesnt light up','Oren','0509221243',3);
INSERT INTO `project`.`applications` (`ApplicationDate`,`ApplicationDescription`,`ContactName`,`ContactPhoneN`,`OperatorID`) VALUES ('2021-03-12','A pit in the middle of the road','Orli','0509332123',4);
INSERT INTO `project`.`applications` (`ApplicationDate`,`ApplicationDescription`,`ContactName`,`ContactPhoneN`,`OperatorID`) VALUES ('2021-02-27','Traffic light not working','Viki','0532893721',5);
INSERT INTO `project`.`applications` (`ApplicationDate`,`ApplicationDescription`,`ContactName`,`ContactPhoneN`,`OperatorID`) VALUES ('2020-07-29','A pit on the road with only a right margin','Avi','0523209484',6);
INSERT INTO `project`.`applications` (`ApplicationDate`,`ApplicationDescription`,`ContactName`,`ContactPhoneN`,`OperatorID`) VALUES ('2020-06-10','A sign fell on a peson while driving and the person was injured','Hila','0509332245',4);
INSERT INTO `project`.`applications` (`ApplicationDate`,`ApplicationDescription`,`ContactName`,`ContactPhoneN`,`OperatorID`) VALUES ('2021-05-06','A car burned and the driver was slightly burned','Moshe','0529348390',4);
INSERT INTO `project`.`applications` (`ApplicationDate`,`ApplicationDescription`,`ContactName`,`ContactPhoneN`,`OperatorID`) VALUES ('2020-07-03','There is a suspicious object in the right margin','Yael','0528349203',3);
INSERT INTO `project`.`applications` (`ApplicationDate`,`ApplicationDescription`,`ContactName`,`ContactPhoneN`,`OperatorID`) VALUES ('2021-08-07','A lamp on the right side of the road doesnt light up','Or','0539282924',6);
INSERT INTO `project`.`applications` (`ApplicationDate`,`ApplicationDescription`,`ContactName`,`ContactPhoneN`,`OperatorID`) VALUES ('2020-07-13','There is  oil on the road','Yael','0532983292',6);
INSERT INTO `project`.`applications` (`ApplicationDate`,`ApplicationDescription`,`ContactName`,`ContactPhoneN`,`OperatorID`) VALUES ('2021-05-16','The marking on the road are not clear','Yoav','0503983934',3);





INSERT INTO `project`.`road` (`ID`,`RoadName`,`RoadLength`,`RoadType`) VALUES (71,'Afola-Beit shein',31,'national road');
INSERT INTO `project`.`road` (`ID`,`RoadName`,`RoadLength`,`RoadType`) VALUES (90,'Arva',478,'national road');
INSERT INTO `project`.`road` (`ID`,`RoadName`,`RoadLength`,`RoadType`) VALUES (65,'Sargel',91,'national road');
INSERT INTO `project`.`road` (`ID`,`RoadName`,`RoadLength`,`RoadType`) VALUES (31,'lehavim',70,'Interurban road');
INSERT INTO `project`.`road` (`ID`,`RoadName`,`RoadLength`,`RoadType`) VALUES (5,'gehaa',36,'Interurban road');


INSERT INTO `project`.`roadsection` (`ID`,`RoadID`) VALUES (1,5);
INSERT INTO `project`.`roadsection` (`ID`,`RoadID`) VALUES (1,31);
INSERT INTO `project`.`roadsection` (`ID`,`RoadID`) VALUES (1,65);
INSERT INTO `project`.`roadsection` (`ID`,`RoadID`) VALUES (1,71);
INSERT INTO `project`.`roadsection` (`ID`,`RoadID`) VALUES (1,90);
INSERT INTO `project`.`roadsection` (`ID`,`RoadID`) VALUES (2,5);
INSERT INTO `project`.`roadsection` (`ID`,`RoadID`) VALUES (2,31);
INSERT INTO `project`.`roadsection` (`ID`,`RoadID`) VALUES (2,65);
INSERT INTO `project`.`roadsection` (`ID`,`RoadID`) VALUES (2,71);
INSERT INTO `project`.`roadsection` (`ID`,`RoadID`) VALUES (2,90);
INSERT INTO `project`.`roadsection` (`ID`,`RoadID`) VALUES (3,5);
INSERT INTO `project`.`roadsection` (`ID`,`RoadID`) VALUES (3,31);
INSERT INTO `project`.`roadsection` (`ID`,`RoadID`) VALUES (3,65);
INSERT INTO `project`.`roadsection` (`ID`,`RoadID`) VALUES (3,71);
INSERT INTO `project`.`roadsection` (`ID`,`RoadID`) VALUES (3,90);

UPDATE `project`.`roadsection` SET `Marings` = '2' WHERE (`ID` = '1') and (`RoadID` = '5');
UPDATE `project`.`roadsection` SET `Marings` = '1' WHERE (`ID` = '1') and (`RoadID` = '31');
UPDATE `project`.`roadsection` SET `Marings` = '2' WHERE (`ID` = '1') and (`RoadID` = '65');
UPDATE `project`.`roadsection` SET `Marings` = '3' WHERE (`ID` = '1') and (`RoadID` = '71');
UPDATE `project`.`roadsection` SET `Marings` = '4' WHERE (`ID` = '1') and (`RoadID` = '90');
UPDATE `project`.`roadsection` SET `Marings` = '3' WHERE (`ID` = '2') and (`RoadID` = '5');
UPDATE `project`.`roadsection` SET `Marings` = '4' WHERE (`ID` = '2') and (`RoadID` = '65');
UPDATE `project`.`roadsection` SET `Marings` = '4' WHERE (`ID` = '2') and (`RoadID` = '31');
UPDATE `project`.`roadsection` SET `Marings` = '3' WHERE (`ID` = '2') and (`RoadID` = '71');
UPDATE `project`.`roadsection` SET `Marings` = '1' WHERE (`ID` = '2') and (`RoadID` = '90');
UPDATE `project`.`roadsection` SET `Marings` = '3' WHERE (`ID` = '3') and (`RoadID` = '5');
UPDATE `project`.`roadsection` SET `Marings` = '1' WHERE (`ID` = '3') and (`RoadID` = '90');
UPDATE `project`.`roadsection` SET `Marings` = '4' WHERE (`ID` = '3') and (`RoadID` = '71');
UPDATE `project`.`roadsection` SET `Marings` = '2' WHERE (`ID` = '3') and (`RoadID` = '65');
UPDATE `project`.`roadsection` SET `Marings` = '2' WHERE (`ID` = '3') and (`RoadID` = '31');

UPDATE `project`.`roadsection` SET `SideLighting` = '1' WHERE (`ID` = '1') and (`RoadID` = '5');
UPDATE `project`.`roadsection` SET `SideLighting` = '2' WHERE (`ID` = '1') and (`RoadID` = '31');
UPDATE `project`.`roadsection` SET `SideLighting` = '1' WHERE (`ID` = '1') and (`RoadID` = '65');
UPDATE `project`.`roadsection` SET `SideLighting` = '2' WHERE (`ID` = '1') and (`RoadID` = '71');
UPDATE `project`.`roadsection` SET `SideLighting` = '3' WHERE (`ID` = '1') and (`RoadID` = '90');
UPDATE `project`.`roadsection` SET `SideLighting` = '4' WHERE (`ID` = '2') and (`RoadID` = '5');
UPDATE `project`.`roadsection` SET `SideLighting` = '4' WHERE (`ID` = '2') and (`RoadID` = '31');
UPDATE `project`.`roadsection` SET `SideLighting` = '4' WHERE (`ID` = '2') and (`RoadID` = '65');
UPDATE `project`.`roadsection` SET `SideLighting` = '3' WHERE (`ID` = '2') and (`RoadID` = '71');
UPDATE `project`.`roadsection` SET `SideLighting` = '2' WHERE (`ID` = '2') and (`RoadID` = '90');
UPDATE `project`.`roadsection` SET `SideLighting` = '4' WHERE (`ID` = '3') and (`RoadID` = '5');
UPDATE `project`.`roadsection` SET `SideLighting` = '1' WHERE (`ID` = '3') and (`RoadID` = '31');
UPDATE `project`.`roadsection` SET `SideLighting` = '3' WHERE (`ID` = '3') and (`RoadID` = '65');
UPDATE `project`.`roadsection` SET `SideLighting` = '3' WHERE (`ID` = '3') and (`RoadID` = '71');
UPDATE `project`.`roadsection` SET `SideLighting` = '1' WHERE (`ID` = '3') and (`RoadID` = '90');

INSERT INTO `project`.`treatmentfactor` (`ID`,`FactorName`,`PhoneNumber`,`Mail`) VALUES (1235,'MDA','033278324','MDA@gmail.com');
INSERT INTO `project`.`treatmentfactor` (`ID`,`FactorName`,`PhoneNumber`,`Mail`) VALUES (1236,'IEC-lighting','039874393','IEC@gmail.com');
INSERT INTO `project`.`treatmentfactor` (`ID`,`FactorName`,`PhoneNumber`,`Mail`) VALUES (1237,'Paz Pits','039348732','PazPits@gmail.com');
INSERT INTO `project`.`treatmentfactor` (`ID`,`FactorName`,`PhoneNumber`,`Mail`) VALUES (1238,'Fire Fighters','039837938','FireFighters@gmail.com');
INSERT INTO `project`.`treatmentfactor` (`ID`,`FactorName`,`PhoneNumber`,`Mail`) VALUES (1239,'YSB trafiic signs','038932049','YSBRepairtrafficsigns@gmail');
INSERT INTO `project`.`treatmentfactor` (`ID`,`FactorName`,`PhoneNumber`,`Mail`) VALUES (1240,'police','038902913','police@gmail.com');
INSERT INTO `project`.`treatmentfactor` (`ID`,`FactorName`,`PhoneNumber`,`Mail`) VALUES (1241,'Adir road marking&cleaning','038392103','adirmarking&cleaning@gmail.com');

INSERT INTO `project`.`hazardtype` (`TypeName`,`Cost`,`TreatmentFactorID`) VALUES ('fire',5000,1238);
INSERT INTO `project`.`hazardtype` (`TypeName`,`Cost`,`TreatmentFactorID`) VALUES ('Human emergency',1500,1235);
INSERT INTO `project`.`hazardtype` (`TypeName`,`Cost`,`TreatmentFactorID`) VALUES ('lighting',1000,1236);
INSERT INTO `project`.`hazardtype` (`TypeName`,`Cost`,`TreatmentFactorID`) VALUES ('pit on the road',4000,1237);
INSERT INTO `project`.`hazardtype` (`TypeName`,`Cost`,`TreatmentFactorID`) VALUES ('road markings are unclear',1000,1241);
INSERT INTO `project`.`hazardtype` (`TypeName`,`Cost`,`TreatmentFactorID`) VALUES ('road not clean',6000,1241);
INSERT INTO `project`.`hazardtype` (`TypeName`,`Cost`,`TreatmentFactorID`) VALUES ('Suspicious object',800,1240);
INSERT INTO `project`.`hazardtype` (`TypeName`,`Cost`,`TreatmentFactorID`) VALUES ('traffic signs',2500,1239);
INSERT INTO `project`.`hazardtype` (`TypeName`,`Cost`,`TreatmentFactorID`) VALUES ('Sewage malfunctions', '900', '1240');


INSERT INTO `project`.`hazard` (`ID`,`EvacuationDate`,`Location`,`HazardTypeName`,`RoadId`,`RoadSectionID`) VALUES (11,'2021-04-16','32°07\'47.0\"N 34°50\'36.5\"E','lighting',5,1);
INSERT INTO `project`.`hazard` (`ID`,`EvacuationDate`,`Location`,`HazardTypeName`,`RoadId`,`RoadSectionID`) VALUES (12,'2020-07-14','32°03\'27.6\"N 34°47\'01.4\"E','lighting',31,2);
INSERT INTO `project`.`hazard` (`ID`,`EvacuationDate`,`Location`,`HazardTypeName`,`RoadId`,`RoadSectionID`) VALUES (13,'2021-03-15','32°30\'17.3\"N 34°54\'49.0\"E','pit on the road',65,2);
INSERT INTO `project`.`hazard` (`ID`,`EvacuationDate`,`Location`,`HazardTypeName`,`RoadId`,`RoadSectionID`) VALUES (14,'2021-02-28','32°42\'41.3\"N 35°17\'54.0\"E','lighting',71,3);
INSERT INTO `project`.`hazard` (`ID`,`EvacuationDate`,`Location`,`HazardTypeName`,`RoadId`,`RoadSectionID`) VALUES (15,'2020-07-29','32°59\'23.9\"N 35°33\'48.7\"E','pit on the road',90,1);
INSERT INTO `project`.`hazard` (`ID`,`EvacuationDate`,`Location`,`HazardTypeName`,`RoadId`,`RoadSectionID`) VALUES (16,'2020-06-10','32°05\'29.1\"N 34°47\'42.5\"E','Human emergency',31,3);
INSERT INTO `project`.`hazard` (`ID`,`EvacuationDate`,`Location`,`HazardTypeName`,`RoadId`,`RoadSectionID`) VALUES (17,'2020-06-11','32°05\'35.7\"N 34°47\'41.0\"E','traffic signs',31,3);
INSERT INTO `project`.`hazard` (`ID`,`EvacuationDate`,`Location`,`HazardTypeName`,`RoadId`,`RoadSectionID`) VALUES (18,'2021-05-06','32°59\'30.6\"N 35°34\'21.8\"E','fire',90,1);
INSERT INTO `project`.`hazard` (`ID`,`EvacuationDate`,`Location`,`HazardTypeName`,`RoadId`,`RoadSectionID`) VALUES (19,'2021-05-06','32°59\'23.6\"N 35°33\'45.3\"E','Human emergency',90,1);
INSERT INTO `project`.`hazard` (`ID`,`EvacuationDate`,`Location`,`HazardTypeName`,`RoadId`,`RoadSectionID`) VALUES (20,'2020-07-03','32°42\'54.3\"N 35°17\'35.3\"E','Suspicious object',71,2);
INSERT INTO `project`.`hazard` (`ID`,`EvacuationDate`,`Location`,`HazardTypeName`,`RoadId`,`RoadSectionID`) VALUES (21,'2021-08-09','32°07\'07.6\"N 34°52\'22.5\"E','lighting',5,3);
INSERT INTO `project`.`hazard` (`ID`,`EvacuationDate`,`Location`,`HazardTypeName`,`RoadId`,`RoadSectionID`) VALUES (22,'2020-07-13','32°30\'13.4\"N 34°54\'26.4\"E','road not clean',65,1);
INSERT INTO `project`.`hazard` (`ID`,`EvacuationDate`,`Location`,`HazardTypeName`,`RoadId`,`RoadSectionID`) VALUES (23,'2021-05-16','32°04\'14.0\"N 34°47\'19.3\"E','road markings are unclear',31,2);

INSERT INTO `project`.`treatment` (`ApplicationID`, `HazardID`) VALUES ('111', '11');
INSERT INTO `project`.`treatment` (`ApplicationID`, `HazardID`) VALUES ('112', '12');
INSERT INTO `project`.`treatment` (`ApplicationID`, `HazardID`) VALUES ('113', '13');
INSERT INTO `project`.`treatment` (`ApplicationID`, `HazardID`) VALUES ('114', '14');
INSERT INTO `project`.`treatment` (`ApplicationID`, `HazardID`) VALUES ('115', '15');
INSERT INTO `project`.`treatment` (`ApplicationID`, `HazardID`) VALUES ('116', '16');
INSERT INTO `project`.`treatment` (`ApplicationID`, `HazardID`) VALUES ('116', '17');
INSERT INTO `project`.`treatment` (`ApplicationID`, `HazardID`) VALUES ('117', '18');
INSERT INTO `project`.`treatment` (`ApplicationID`, `HazardID`) VALUES ('117', '19');
INSERT INTO `project`.`treatment` (`ApplicationID`, `HazardID`) VALUES ('118', '20');
INSERT INTO `project`.`treatment` (`ApplicationID`, `HazardID`) VALUES ('119', '21');
INSERT INTO `project`.`treatment` (`ApplicationID`, `HazardID`) VALUES ('120', '22');
INSERT INTO `project`.`treatment` (`ApplicationID`, `HazardID`) VALUES ('121', '23');

INSERT INTO `project`.`applications` (`ID`, `ApplicationDate`, `ApplicationDescription`, `ContactName`, `ContactPhoneN`, `OperatorID`) VALUES ('122', '2021-04-16', 'A lamp on the right side of the road doesnt light up', 'eli', '0529443266', '4');
INSERT INTO `project`.`treatment` (`ApplicationID`, `HazardID`) VALUES ('122', '11');
INSERT INTO `project`.`applications` (`ID`, `ApplicationDate`, `ApplicationDescription`, `ContactName`, `ContactPhoneN`, `OperatorID`) VALUES ('123', '2020-07-13', 'A lamp on the left  side of the road doesnt light up', 'Michal', '0503983934', '6');
INSERT INTO `project`.`treatment` (`ApplicationID`, `HazardID`) VALUES ('123', '12');
INSERT INTO `project`.`applications` (`ID`, `ApplicationDate`, `ApplicationDescription`, `ContactName`, `ContactPhoneN`, `OperatorID`) VALUES ('124', '2021-03-12', 'A pit in the middle of the road', 'Yael', '0532983292', '5');
INSERT INTO `project`.`treatment` (`ApplicationID`, `HazardID`) VALUES ('124', '22');

####Q1####
SELECT operator.ID,operator.FirstName, operator.LastName,
group_concat(phoneNumbers.PhoneNumber) AS 'phoneNumbers'
FROM operator
	INNER JOIN phonenumbers ON operator.ID=phonenumbers.OperatorID		
GROUP BY operator.ID, operator.FirstName, operator.LastName;

###Q2###
SELECT hazardtype.TypeName, count(hazard.HazardTypeName), hazardtype.Cost AS CostToOne,
		count(hazard.HazardTypeName)*hazardtype.Cost AS TotalCost
FROM hazard
	RIGHT JOIN hazardtype ON hazard.HazardTypeName = hazardtype.TypeName
GROUP BY hazard.HazardTypeName
HAVING count(hazardtype.TypeName)*hazardtype.Cost > 800
ORDER BY count(hazardtype.TypeName)*hazardtype.Cost DESC;

###Q3####
SELECT treatment.ApplicationID, applications.ApplicationDate, treatment.HazardID, hazard.EvacuationDate,
		DATEDIFF(hazard.EvacuationDate, applications.ApplicationDate) AS difference
FROM treatment
	INNER JOIN applications ON treatment.ApplicationID=applications.ID
    INNER JOIN hazard ON treatment.HazardID = hazard.ID
    WHERE DATEDIFF(hazard.EvacuationDate, applications.ApplicationDate) > 1;
    

###Q4###
SELECT r.RoadName, r.ID
FROM hazard h, road r, roadsection rs
WHERE h.RoadSectionID = rs.ID
	AND r.ID = rs.RoadID
    AND (rs.SideLighting = 'LEFT' OR rs.SideLighting = 'RIGHT')
GROUP BY r.ID;

###Q5###
SELECT t.ApplicationID , count(t.HazardID), h.RoadId
FROM hazard h, treatment t
WHERE h.ID = t.HazardID
GROUP BY t.ApplicationID
HAVING count(t.HazardID) > 1
ORDER BY t.ApplicationID;

###Q6###
SELECT r.RoadName, rs.RoadID, rs.ID AS 'RoadSection', r.RoadLength
FROM road r INNER JOIN roadsection rs ON (rs.RoadID = r.ID)
WHERE rs.Marings = 'NONE' AND rs.SideLighting = 'NONE';

###Q7###
SELECT count(h.ID), h.RoadSectionID, h.RoadId
FROM road r, hazard h
WHERE r.ID = h.RoadId 
GROUP BY h.RoadId, h.RoadSectionID
ORDER BY count(h.ID) DESC
LIMIT 3;

###Q8###
SELECT t.HazardID, h.EvacuationDate, h.HazardTypeName
FROM hazard h, treatment t
WHERE h.ID = t.HazardID
GROUP BY t.HazardID
having count(t.HazardID) > 1
ORDER BY t.HazardID; 

###Q9###
SELECT o1.ID, o1.FirstName, o1.LastName, o2.ID, o2.FirstName, o2.LastName
FROM operator o1, operator o2
WHERE o1.ID < o2.ID 
	AND o1.ID != 1;
	  
###Q10 ###
SELECT  applications.ApplicationDate, applications.ApplicationDescription,
		applications.OperatorID, operator.FirstName, operator.LastName
FROM applications 
	INNER JOIN operator ON applications.OperatorID = operator.ID
WHERE ApplicationDate LIKE '2020-07-13'; 

###Q11###
SELECT h.ID AS HazardId ,EvacuationDate ,RoadName
FROM hazard h, road r
WHERE h.RoadId = r.ID
	AND h.EvacuationDate LIKE '2021-05-06';
    
 ###Q12###
SELECT operator.FirstName, operator.LastName, count(applications.OperatorID)
FROM operator
	INNER JOIN applications ON operator.ID = applications.OperatorID
WHERE applications.ApplicationDate BETWEEN '2020-07-02' AND '2020-08-01'	
GROUP BY  operator.ID, operator.FirstName, operator.LastName
HAVING count(applications.OperatorID)  >1   
ORDER BY applications.OperatorID DESC;    
            		
 
 
###Q INSERT 1###
INSERT INTO applications(ApplicationDate, ApplicationDescription, ContactName, 
			ContactPhoneN, OperatorID)
SELECT '2022-01-01', ApplicationDescription, 'Or', ContactPhoneN, 6
FROM applications
WHERE OperatorID = 6
	AND ContactName LIKE 'Or%';
    
###Q INSERT 2###
INSERT INTO operator(FirstName,LastName,StreetNumber, HouseNumber, city, Mail, ManagerID)
			VALUES('Lilach','Levi',6,36,'Holon','lilachl@gmail.com',2)
            ,('Yulia','Sharon',46,40,'Tel-Aviv','Yulia@gmail.com',1)
            ,('Nati','Komet',77,16,'Petah Tiqva','Nati@gmail.com',1);
           
	    
###Q UPDATE###
SET SQL_SAFE_UPDATES=0;
UPDATE hazardtype
SET Cost = Cost*1.25
WHERE Cost < 1200;  

##Q DELETE###
DELETE FROM hazard
WHERE hazard.EvacuationDate < '2020-08-08'
	AND hazard.RoadId = '71'
    AND hazard.RoadSectionID = '2'; 